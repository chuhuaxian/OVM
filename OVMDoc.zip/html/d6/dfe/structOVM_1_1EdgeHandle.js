var structOVM_1_1EdgeHandle =
[
    [ "EdgeHandle", "d6/dfe/structOVM_1_1EdgeHandle.html#a402a6c9ba1cfa720aed34f7ec3c83b1c", null ]
];