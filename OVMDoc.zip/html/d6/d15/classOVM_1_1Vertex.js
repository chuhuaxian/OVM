var classOVM_1_1Vertex =
[
    [ "Vertex", "d6/d15/classOVM_1_1Vertex.html#a546d1c1060ac6ed1320989b89cb85528", null ],
    [ "TopologyKernel", "d6/d15/classOVM_1_1Vertex.html#a13584d9a983a1f4114c030c2802c5192", null ],
    [ "heh_", "d6/d15/classOVM_1_1Vertex.html#aab4f21a4e716e6e352dc2250e44c135a", null ]
];