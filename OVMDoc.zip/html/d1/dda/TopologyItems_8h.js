var TopologyItems_8h =
[
    [ "Face", "dd/d6b/classOVM_1_1Face.html", "dd/d6b/classOVM_1_1Face" ],
    [ "HalfEdge", "dd/d2e/classOVM_1_1HalfEdge.html", "dd/d2e/classOVM_1_1HalfEdge" ],
    [ "HalfFace", "d4/d73/classOVM_1_1HalfFace.html", "d4/d73/classOVM_1_1HalfFace" ],
    [ "Hedron", "d5/d33/classOVM_1_1Hedron.html", "d5/d33/classOVM_1_1Hedron" ],
    [ "Vertex", "d6/d15/classOVM_1_1Vertex.html", "d6/d15/classOVM_1_1Vertex" ],
    [ "HedronHandle", "d1/dda/TopologyItems_8h.html#a9725ddca87c72b9d83e86da2c3a65e61", null ]
];