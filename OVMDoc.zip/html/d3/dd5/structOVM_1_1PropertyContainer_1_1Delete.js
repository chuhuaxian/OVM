var structOVM_1_1PropertyContainer_1_1Delete =
[
    [ "Delete", "d3/dd5/structOVM_1_1PropertyContainer_1_1Delete.html#ae852a899d2bf02a2a0c37fe641d6fa16", null ],
    [ "operator()", "d3/dd5/structOVM_1_1PropertyContainer_1_1Delete.html#ad60986f9f8a919b4054dfc2bb0e3f019", null ]
];