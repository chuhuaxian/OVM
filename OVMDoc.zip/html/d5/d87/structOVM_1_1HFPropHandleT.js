var structOVM_1_1HFPropHandleT =
[
    [ "Value", "d5/d87/structOVM_1_1HFPropHandleT.html#a8c8790c745a91e21495c38ede993549a", null ],
    [ "value_type", "d5/d87/structOVM_1_1HFPropHandleT.html#ae6ef454db855846c331bf0583a5577f9", null ],
    [ "HFPropHandleT", "d5/d87/structOVM_1_1HFPropHandleT.html#a8bc36338c2127d6acf61d8ec17247ae7", null ],
    [ "HFPropHandleT", "d5/d87/structOVM_1_1HFPropHandleT.html#a404869ed477a43a1b1ecc9cd925650dd", null ]
];