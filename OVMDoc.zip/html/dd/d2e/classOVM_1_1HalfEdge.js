var classOVM_1_1HalfEdge =
[
    [ "HalfEdge", "dd/d2e/classOVM_1_1HalfEdge.html#a566ab43f97593512cd562c4864d0a23e", null ],
    [ "TopologyKernel", "dd/d2e/classOVM_1_1HalfEdge.html#a13584d9a983a1f4114c030c2802c5192", null ],
    [ "fh_", "dd/d2e/classOVM_1_1HalfEdge.html#a605ff81e5f12101eb784f333ee574cf0", null ],
    [ "opp_heh_", "dd/d2e/classOVM_1_1HalfEdge.html#a9f66bde61742f95c50d30a92c9f41597", null ],
    [ "vh_", "dd/d2e/classOVM_1_1HalfEdge.html#a1b64619d86158c4fd3394c9e88dc411c", null ]
];