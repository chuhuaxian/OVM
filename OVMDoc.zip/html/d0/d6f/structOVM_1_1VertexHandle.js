var structOVM_1_1VertexHandle =
[
    [ "VertexHandle", "d0/d6f/structOVM_1_1VertexHandle.html#a332dd46ddfc09af8186744d49032f438", null ]
];