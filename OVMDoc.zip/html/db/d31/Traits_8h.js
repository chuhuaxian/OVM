var Traits_8h =
[
    [ "DefaultTraits", "dc/d67/structOVM_1_1DefaultTraits.html", "dc/d67/structOVM_1_1DefaultTraits" ],
    [ "HAttributes", "db/d31/Traits_8h.html#ab55633f8cfed05caae56c5ae7a0b20b9", null ],
    [ "HEAttributes", "db/d31/Traits_8h.html#a539fc44d84430468a6541e84c79058f2", null ],
    [ "HFAttributes", "db/d31/Traits_8h.html#a3b68732d56c4133f235d06b70c691557", null ],
    [ "VAttributes", "db/d31/Traits_8h.html#ae96470907689c4f6a11fe762cbe45b57", null ]
];