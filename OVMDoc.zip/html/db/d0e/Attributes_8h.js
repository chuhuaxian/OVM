var Attributes_8h =
[
    [ "AttributeBits", "db/d0e/Attributes_8h.html#a8c5d57590fbd539971915eb384c63ed8", [
      [ "None", "db/d0e/Attributes_8h.html#a8c5d57590fbd539971915eb384c63ed8ac4f8c58bd900edd22fa75a08aaa31f58", null ],
      [ "HalfFaceNormal", "db/d0e/Attributes_8h.html#a8c5d57590fbd539971915eb384c63ed8a645c15ca00e287ad9169abd9f7f8fe30", null ],
      [ "HalfFaceRegion", "db/d0e/Attributes_8h.html#a8c5d57590fbd539971915eb384c63ed8aaf297a87e0193edf3acfa123e34b808b", null ],
      [ "HedronRegion", "db/d0e/Attributes_8h.html#a8c5d57590fbd539971915eb384c63ed8a93eb428bd87056bcc0ade650ca6ee070", null ],
      [ "Status", "db/d0e/Attributes_8h.html#a8c5d57590fbd539971915eb384c63ed8a007afc1b42a67ef14db155cf36ece7ee", null ]
    ] ]
];