var structMyTrait =
[
    [ "Normal", "db/df1/structMyTrait.html#a10be144ed10b5a06d12b4cb80cec3649", null ],
    [ "Normal", "db/df1/structMyTrait.html#a10be144ed10b5a06d12b4cb80cec3649", null ],
    [ "Point", "db/df1/structMyTrait.html#acf282bbe7b872fa44dfa0576da8f46e4", null ],
    [ "Point", "db/df1/structMyTrait.html#acf282bbe7b872fa44dfa0576da8f46e4", null ]
];