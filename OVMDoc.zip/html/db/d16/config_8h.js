var config_8h =
[
    [ "_ENABLETEMPLATE_", "db/d16/config_8h.html#a060d9b68ffc7cc5f3c60b0c06e4ef1ae", null ],
    [ "OVM_GET_MAJ", "db/d16/config_8h.html#a77d85eb9c565d82d418ccd9ee40d34cf", null ],
    [ "OVM_GET_MIN", "db/d16/config_8h.html#aedb58288a432b67c70c4888ef330c14a", null ],
    [ "OVM_GET_VER", "db/d16/config_8h.html#ab561f7ee5cb025b8948942bca96e292b", null ],
    [ "OVM_VERSION", "db/d16/config_8h.html#aaf22bef3948461cf4ef37af2f82d4ce0", null ],
    [ "OVM_VERSION_", "db/d16/config_8h.html#a43edea1f02359bc830c279f443879a01", null ],
    [ "uint", "db/d16/config_8h.html#a91ad9478d81a7aaf2593e8d9c3d06a14", null ]
];