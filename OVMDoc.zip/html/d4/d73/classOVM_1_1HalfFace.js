var classOVM_1_1HalfFace =
[
    [ "HalfFace", "d4/d73/classOVM_1_1HalfFace.html#a2dcdec2680a9b50da1a989a43719e011", null ],
    [ "TopologyKernel", "d4/d73/classOVM_1_1HalfFace.html#a13584d9a983a1f4114c030c2802c5192", null ],
    [ "heh_", "d4/d73/classOVM_1_1HalfFace.html#a16ff0693e85855899c1c834cdee533a8", null ],
    [ "opp_hfh_", "d4/d73/classOVM_1_1HalfFace.html#af029189bea79817a89b78ce8e6f172fa", null ]
];