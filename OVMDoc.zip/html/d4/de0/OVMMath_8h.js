var OVMMath_8h =
[
    [ "OVMT_EPS", "d4/de0/OVMMath_8h.html#a045e5c8c4caeb0742d5529e2dd2621fd", null ],
    [ "OVMT_MAX", "d4/de0/OVMMath_8h.html#a91f253b1a14d5616c632503ac2729bd3", null ],
    [ "determination_3x3", "d4/de0/OVMMath_8h.html#a7d81f3f4c9d66a2ffe398de483666992", null ],
    [ "linear_transformation", "d4/de0/OVMMath_8h.html#a64d9822977cad150127c52ca477b51b8", null ],
    [ "linear_transformation", "d4/de0/OVMMath_8h.html#a7611c15a5299b12c852a8a30def79b50", null ],
    [ "solve_linear_system_3x3", "d4/de0/OVMMath_8h.html#a960292266c85d55dafa07055a7148f99", null ],
    [ "zero_value", "d4/de0/OVMMath_8h.html#aae1f6cbb957ee6c1121efe88b6241993", null ],
    [ "OVM_EPS", "d4/de0/OVMMath_8h.html#afda0b33c618cec68466eb851cfc74b21", null ],
    [ "OVM_MAX", "d4/de0/OVMMath_8h.html#a66690e8748d57d1a033662152aacc73c", null ],
    [ "OVM_PI", "d4/de0/OVMMath_8h.html#a15aff92ec4be2a9d619088b9e6ba6c8d", null ]
];