var structOVM_1_1HalfFaceHandle =
[
    [ "HalfFaceHandle", "d8/dc3/structOVM_1_1HalfFaceHandle.html#ada0be0a245886fbb0085e0a32540605a", null ]
];