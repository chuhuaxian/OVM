var structOVM_1_1vector__traits =
[
    [ "value_type", "d7/d7b/structOVM_1_1vector__traits.html#a680e4b2c5d2dd498566e353b5d0a92d0", null ],
    [ "vector_type", "d7/d7b/structOVM_1_1vector__traits.html#af64d59999f6e0f7131fa1784f652354b", null ]
];