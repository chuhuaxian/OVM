var classOVM_1_1BaseHandle =
[
    [ "BaseHandle", "d7/de2/classOVM_1_1BaseHandle.html#a3504ee612d99f9e68798d2039f17cb6c", null ],
    [ "__decrement", "d7/de2/classOVM_1_1BaseHandle.html#af9c658b1d602d5957f348e557f34eb9a", null ],
    [ "__increment", "d7/de2/classOVM_1_1BaseHandle.html#a79c8126e25c88f17f0f296bf94e21a8a", null ],
    [ "idx", "d7/de2/classOVM_1_1BaseHandle.html#a086cfab5529165eb5f30952e9d7201a6", null ],
    [ "invalidate", "d7/de2/classOVM_1_1BaseHandle.html#a18ca2a4bdcbb5ccc76973341e2f3d8aa", null ],
    [ "is_valid", "d7/de2/classOVM_1_1BaseHandle.html#ac8fb8c0c75af1ba02c3457e43d11b18a", null ],
    [ "operator __int64", "d7/de2/classOVM_1_1BaseHandle.html#a0bee87c01ba300c32870c0ec8adead48", null ],
    [ "operator int", "d7/de2/classOVM_1_1BaseHandle.html#a5535e0a4fa205880e09f616efe832f97", null ],
    [ "operator size_t", "d7/de2/classOVM_1_1BaseHandle.html#ac2db91f1b33c1da35a38fc5c165f7a63", null ],
    [ "operator!=", "d7/de2/classOVM_1_1BaseHandle.html#ae02abb1583c18988256dd9bd664d7bba", null ],
    [ "operator++", "d7/de2/classOVM_1_1BaseHandle.html#a9e8151ad84e8ae995f09663bd82cbb2e", null ],
    [ "operator--", "d7/de2/classOVM_1_1BaseHandle.html#ada288415acc42398dc2dff27dbead43d", null ],
    [ "operator<", "d7/de2/classOVM_1_1BaseHandle.html#ac8c7224f30bc312922b2346d4b868b04", null ],
    [ "operator==", "d7/de2/classOVM_1_1BaseHandle.html#acedf1a83d6c021ded30a61947f22d2ee", null ],
    [ "reset", "d7/de2/classOVM_1_1BaseHandle.html#aa4fb652b51d62d4700c1a7354e217627", null ],
    [ "set_idx", "d7/de2/classOVM_1_1BaseHandle.html#a7a4f557a2442d81d526e2605d4f1f199", null ],
    [ "idx_", "d7/de2/classOVM_1_1BaseHandle.html#a5a3868c0f64aebf26bb7b14a4af20bb9", null ]
];