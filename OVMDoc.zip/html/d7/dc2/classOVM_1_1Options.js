var classOVM_1_1Options =
[
    [ "enum_type", "d7/dc2/classOVM_1_1Options.html#a101d93de2bdc23c719d8346e4c0f9190", null ],
    [ "value_type", "d7/dc2/classOVM_1_1Options.html#ac815db4777bbdd4ecb76b53f81b27bcc", null ],
    [ "Flag", "d7/dc2/classOVM_1_1Options.html#a543dc0cf7015c0d4c2d5448d6d42ff5c", [
      [ "Default", "d7/dc2/classOVM_1_1Options.html#a543dc0cf7015c0d4c2d5448d6d42ff5ca6aee646e4d953e0f7478044d4efa632d", null ],
      [ "Binary", "d7/dc2/classOVM_1_1Options.html#a543dc0cf7015c0d4c2d5448d6d42ff5caf7a4ec031246851eae2baf365aab850b", null ],
      [ "HalfFaceRegion", "d7/dc2/classOVM_1_1Options.html#a543dc0cf7015c0d4c2d5448d6d42ff5caafab0f8aad7bca3a9f5df2b130bde283", null ],
      [ "HedronRegion", "d7/dc2/classOVM_1_1Options.html#a543dc0cf7015c0d4c2d5448d6d42ff5ca34f0a8bca6f18762c07862b670af8ef5", null ]
    ] ],
    [ "Options", "d7/dc2/classOVM_1_1Options.html#aa77bc3b87fdaa83bf660cb273c7cb6dd", null ],
    [ "Options", "d7/dc2/classOVM_1_1Options.html#ae65a6110f8def9daaad5fdd635537042", null ],
    [ "Options", "d7/dc2/classOVM_1_1Options.html#a919ebecd6336514d3da837fc1f91631d", null ],
    [ "Options", "d7/dc2/classOVM_1_1Options.html#a2ef7f7850f6dbd3182efa5455c58a4b4", null ],
    [ "~Options", "d7/dc2/classOVM_1_1Options.html#ab9c53ebb96cbd5bbf0d501d0065bf6de", null ],
    [ "check", "d7/dc2/classOVM_1_1Options.html#a7a8c885769a3462550e5ed1ecaa46b2e", null ],
    [ "cleanup", "d7/dc2/classOVM_1_1Options.html#afba0f855222b24d99190d0a1c37976ce", null ],
    [ "clear", "d7/dc2/classOVM_1_1Options.html#ad87df38e61f164fa7e43fa91e897f8b0", null ],
    [ "half_face_has_region", "d7/dc2/classOVM_1_1Options.html#a0b54e298377674960b61b6b38b8ab5fa", null ],
    [ "hedron_has_region", "d7/dc2/classOVM_1_1Options.html#a26e9ef0ca6c6b9159c37dec892a11cde", null ],
    [ "is_binary", "d7/dc2/classOVM_1_1Options.html#a5cf8d30c38b2efbe35578d46244a8b58", null ],
    [ "is_empty", "d7/dc2/classOVM_1_1Options.html#a639add939dea035d0633a29581654c6f", null ],
    [ "operator value_type", "d7/dc2/classOVM_1_1Options.html#a12cf03e5a6e9b67f26ed114b67975099", null ],
    [ "operator!=", "d7/dc2/classOVM_1_1Options.html#a7199b2210210fbce56b44ae58225f7c2", null ],
    [ "operator+=", "d7/dc2/classOVM_1_1Options.html#ac7195a0ceedf7b2cbc719f659a75bc94", null ],
    [ "operator-=", "d7/dc2/classOVM_1_1Options.html#abd392ac0242b4ed79c9ed87f72aa9d7b", null ],
    [ "operator=", "d7/dc2/classOVM_1_1Options.html#a0425deacaa0a3730cc69243e06482e0d", null ],
    [ "operator=", "d7/dc2/classOVM_1_1Options.html#a18e7723e1550fde144ccb39d6f6714e8", null ],
    [ "operator==", "d7/dc2/classOVM_1_1Options.html#a1c15fe62128ac2b5c55ed6c2250dcfeb", null ],
    [ "set", "d7/dc2/classOVM_1_1Options.html#a767f2013e93dc0ecd5740ebb4ee3ef9e", null ],
    [ "unset", "d7/dc2/classOVM_1_1Options.html#a5c959cc79560e4e3a70fbb0531a4020c", null ],
    [ "flags_", "d7/dc2/classOVM_1_1Options.html#ad7bbbe4f692be881c0870a27266d424c", null ]
];