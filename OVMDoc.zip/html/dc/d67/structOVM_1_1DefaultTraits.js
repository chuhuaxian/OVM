var structOVM_1_1DefaultTraits =
[
    [ "Normal", "dc/d67/structOVM_1_1DefaultTraits.html#a0a409f7b6b588f836e31b01b3146b7f2", null ],
    [ "Point", "dc/d67/structOVM_1_1DefaultTraits.html#a57592d60ad9145125278ae4094d5d310", null ],
    [ "HAttributes", "dc/d67/structOVM_1_1DefaultTraits.html#a1a320ea3ca67b11b3aff424957e8d7a1", null ],
    [ "HEAttributes", "dc/d67/structOVM_1_1DefaultTraits.html#a8caac657eed26fa5fbdb39fa2a33f51c", null ],
    [ "HFAttributes", "dc/d67/structOVM_1_1DefaultTraits.html#aeb85f67561a4048e4ff0bdec3ba773e9", null ],
    [ "VAttributes", "dc/d67/structOVM_1_1DefaultTraits.html#a226c720589dd6ed950514969ea43ba60", null ]
];