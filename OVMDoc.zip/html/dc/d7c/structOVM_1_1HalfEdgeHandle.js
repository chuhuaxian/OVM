var structOVM_1_1HalfEdgeHandle =
[
    [ "HalfEdgeHandle", "dc/d7c/structOVM_1_1HalfEdgeHandle.html#ae045199098778b93f3b833ec4590bb9f", null ]
];