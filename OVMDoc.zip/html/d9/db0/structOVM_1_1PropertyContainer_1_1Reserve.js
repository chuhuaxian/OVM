var structOVM_1_1PropertyContainer_1_1Reserve =
[
    [ "Reserve", "d9/db0/structOVM_1_1PropertyContainer_1_1Reserve.html#aa14ca85966ab96746f38cea5bcfce6f2", null ],
    [ "operator()", "d9/db0/structOVM_1_1PropertyContainer_1_1Reserve.html#ae968c7c058cbaad4e463772d73896607", null ],
    [ "n_", "d9/db0/structOVM_1_1PropertyContainer_1_1Reserve.html#a95e3c5976e5ed42c356f4d2ac33ce2da", null ]
];